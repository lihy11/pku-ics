#
# This file contains course and lab specific parameters for drivers.
#
package Driverhdrs;

# This is no longer needed
$COURSE_NAME = "15213-s16";

# No need to ever update these
$LAB = "datalab";
$SERVER_NAME = "unofficial.fish.ics.cs.cmu.edu";
$SERVER_PORT = "80";
$AUTOGRADE_TIMEOUT = "300";
1;
