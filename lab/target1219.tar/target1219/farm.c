/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_362(unsigned x)
{
    return x + 3281031256U;
}

unsigned getval_290()
{
    return 3284633928U;
}

unsigned addval_119(unsigned x)
{
    return x + 3281000590U;
}

void setval_458(unsigned *p)
{
    *p = 2445773128U;
}

unsigned addval_116(unsigned x)
{
    return x + 3284633960U;
}

void setval_264(unsigned *p)
{
    *p = 3347663010U;
}

unsigned addval_215(unsigned x)
{
    return x + 2425378832U;
}

void setval_493(unsigned *p)
{
    *p = 2420696806U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_452(unsigned x)
{
    return x + 3353381192U;
}

unsigned addval_462(unsigned x)
{
    return x + 2446428443U;
}

unsigned getval_162()
{
    return 2497743176U;
}

void setval_231(unsigned *p)
{
    *p = 2430634312U;
}

void setval_342(unsigned *p)
{
    *p = 3525890441U;
}

unsigned addval_411(unsigned x)
{
    return x + 3374367433U;
}

void setval_331(unsigned *p)
{
    *p = 3525365389U;
}

unsigned addval_185(unsigned x)
{
    return x + 3767093339U;
}

unsigned getval_224()
{
    return 3676361099U;
}

unsigned getval_465()
{
    return 3532968329U;
}

unsigned addval_494(unsigned x)
{
    return x + 3523792521U;
}

unsigned addval_246(unsigned x)
{
    return x + 3372794505U;
}

void setval_267(unsigned *p)
{
    *p = 2425409921U;
}

unsigned addval_378(unsigned x)
{
    return x + 2464188744U;
}

unsigned addval_491(unsigned x)
{
    return x + 3380924809U;
}

unsigned getval_357()
{
    return 3375943304U;
}

unsigned addval_253(unsigned x)
{
    return x + 3380920985U;
}

void setval_272(unsigned *p)
{
    *p = 2425671305U;
}

unsigned addval_184(unsigned x)
{
    return x + 3229929865U;
}

void setval_449(unsigned *p)
{
    *p = 3227566729U;
}

unsigned getval_252()
{
    return 2429454828U;
}

unsigned addval_456(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_431()
{
    return 2425406081U;
}

unsigned getval_101()
{
    return 3682910889U;
}

void setval_418(unsigned *p)
{
    *p = 3525362313U;
}

unsigned addval_486(unsigned x)
{
    return x + 3677409673U;
}

unsigned getval_498()
{
    return 3232026249U;
}

unsigned getval_207()
{
    return 3252717896U;
}

void setval_195(unsigned *p)
{
    *p = 2425540233U;
}

unsigned getval_211()
{
    return 3524838025U;
}

unsigned getval_102()
{
    return 2430634314U;
}

unsigned addval_430(unsigned x)
{
    return x + 3465396354U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
